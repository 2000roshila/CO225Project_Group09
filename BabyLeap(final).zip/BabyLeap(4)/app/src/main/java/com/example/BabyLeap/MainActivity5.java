package com.example.BabyLeap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity5 extends AppCompatActivity {

    String username;
    Button weight,height,upVaccine,vDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        username=getIntent().getStringExtra("USERNAME");
        weight=(Button)findViewById(R.id.weight);
        height=(Button)findViewById(R.id.height);
        upVaccine=(Button)findViewById(R.id.upVaccine);
        vDetails=(Button)findViewById(R.id.vdetails);

        weight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity8();
            }
        });
       height.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity7();
            }
        });
        upVaccine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity9();
            }
        });
        vDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity12();
            }
        });

    }

    private void openActivity7() {
        Intent intent =new Intent(this,MainActivity7.class);
        intent.putExtra("USERNAME",username);
        startActivity(intent);
    }

    private void openActivity12() {
        Intent intent =new Intent(this,MainActivity12.class);
        intent.putExtra("USERNAME",username);
        startActivity(intent);
    }

    private void openActivity9() {
        Intent intent =new Intent(this,MainActivity9.class);
        intent.putExtra("USERNAME",username);
        startActivity(intent);
    }

    private void openActivity8() {
        Intent intent =new Intent(this,MainActivity8.class);
        intent.putExtra("USERNAME",username);
        startActivity(intent);
    }
}