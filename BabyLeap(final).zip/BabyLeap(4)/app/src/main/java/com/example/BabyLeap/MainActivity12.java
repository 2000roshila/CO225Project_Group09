package com.example.BabyLeap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity12 extends AppCompatActivity {

    EditText va1,va2,va3,va4,va5,va6,va7,va8,va9;
    DatabaseReference reference;
    Button goBack;
    String username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main12);

        username=getIntent().getStringExtra("USERNAME");
        va1=(EditText)findViewById(R.id.va1);
        va2=(EditText)findViewById(R.id.va2);
        va3=(EditText)findViewById(R.id.va3);
        va4=(EditText)findViewById(R.id.va4);
        va5=(EditText)findViewById(R.id.va5);
        va6=(EditText)findViewById(R.id.va6);
        va7=(EditText)findViewById(R.id.va7);
        va8=(EditText)findViewById(R.id.va8);
        va9=(EditText)findViewById(R.id.va9);
        goBack=(Button)findViewById(R.id.goback);
        reference= FirebaseDatabase.getInstance().getReference("Vaccines").child(username);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.child("stateVaccine1").getValue().equals(true)){
                    va1.setText(snapshot.child("administeredDate1").getValue().toString().trim());
                }
                else{
                    va1.setText("Not Administered yet");
                }

                if(snapshot.child("stateVaccine2").getValue().equals(true)){
                    va2.setText(snapshot.child("administeredDate2").getValue().toString().trim());
                }
                else{
                    va2.setText("Not Administered yet");
                }

                if(snapshot.child("stateVaccine3").getValue().equals(true)){
                    va3.setText(snapshot.child("administeredDate3").getValue().toString().trim());
                }
                else{
                    va3.setText("Not Administered yet");
                }

                if(snapshot.child("stateVaccine4").getValue().equals(true)){
                    va4.setText(snapshot.child("administeredDate4").getValue().toString().trim());
                }
                else{
                    va4.setText("Not Administered yet");
                }

                if(snapshot.child("stateVaccine5").getValue().equals(true)){
                    va5.setText(snapshot.child("administeredDate5").getValue().toString().trim());
                }
                else{
                    va5.setText("Not Administered yet");
                }

                if(snapshot.child("stateVaccine6").getValue().equals(true)){
                    va6.setText(snapshot.child("administeredDate6").getValue().toString().trim());
                }
                else{
                    va6.setText("Not Administered yet");
                }

                if(snapshot.child("stateVaccine7").getValue().equals(true)){
                    va7.setText(snapshot.child("administeredDate7").getValue().toString().trim());
                }
                else{
                    va7.setText("Not Administered yet");
                }

                if(snapshot.child("stateVaccine8").getValue().equals(true)){
                    va8.setText(snapshot.child("administeredDate8").getValue().toString().trim());
                }
                else{
                    va8.setText("Not Administered yet");
                }

                if(snapshot.child("stateVaccine9").getValue().equals(true)){
                    va9.setText(snapshot.child("administeredDate9").getValue().toString().trim());
                }
                else{
                    va9.setText("Not Administered yet");
                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        goBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity5();
            }
        });


    }

    private void openActivity5() {
        Intent intent =new Intent(this,MainActivity5.class);
        intent.putExtra("USERNAME",username);
        startActivity(intent);
    }
}