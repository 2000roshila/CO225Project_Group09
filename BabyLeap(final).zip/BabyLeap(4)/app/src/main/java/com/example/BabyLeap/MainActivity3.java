package com.example.BabyLeap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class MainActivity3 extends AppCompatActivity {

    EditText username,password;
    Button mButton1;
    Button mButton2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);


        mButton2 =(Button)findViewById(R.id.goback);
        mButton1 =(Button)findViewById(R.id.login);
        username=(EditText)findViewById(R.id.username);
        password=(EditText)findViewById(R.id.password);


        mButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Users");
                Query checkUser=reference.orderByChild("username").equalTo(username.getText().toString().trim());
                checkUser.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.exists()){
                            String PasswordDB=snapshot.child("password").getValue(String.class);
                            if (PasswordDB.equals(password)){
                                startActivity5();

                            }
                            else{
                                startActivity3();
                            }
                        }
                        else{
                            startActivity3();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }


        });


        mButton2.setOnClickListener(view -> startActivity(new Intent(MainActivity3.this, MainActivity.class)));






    }

    private void startActivity5(){
        Intent intent =new Intent(this,MainActivity5.class);

        startActivity(intent);
    }

    private void startActivity3(){
        Intent intent =new Intent(this,MainActivity3.class);
        startActivity(intent);
    }
}