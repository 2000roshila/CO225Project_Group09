package com.example.BabyLeap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.BabyLeap.ui.Users;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity2 extends AppCompatActivity {


     EditText parentName,nic,email,username,password;
     RadioButton radioButton;
     RadioGroup radioGroup;
     DatabaseReference reff;
     Users user;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Button mButton1;
        mButton1 =(Button)findViewById(R.id.next);
        radioGroup=findViewById(R.id.radio);
        parentName=(EditText)findViewById(R.id.parentname);
        nic=(EditText)findViewById(R.id.nic);
        email=(EditText)findViewById(R.id.email);
        username=(EditText)findViewById(R.id.username);
        password=(EditText)findViewById(R.id.password);
        int radioId=radioGroup.getCheckedRadioButtonId();
        radioButton=findViewById(radioId);
        user=new Users();
        reff= FirebaseDatabase.getInstance().getReference("Users");

        mButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user.setUsername(username.getText().toString().trim());
                user.setParentname(parentName.getText().toString().trim());
                user.setEmail(email.getText().toString().trim());
                user.setNic(nic.getText().toString().trim());
                user.setPassword(password.getText().toString().trim());
                user.setGender(radioButton.getText().toString().trim());
                openActivity4();



            }
        });

    }
    public void checkButton(View v){

        int radioId=radioGroup.getCheckedRadioButtonId();
        radioButton=findViewById(radioId);

    }
    public void openActivity4(){

        Intent intent =new Intent(this,MainActivity4.class);
        intent.putExtra("DB_INSTANCE",user);
        intent.putExtra("USERNAME",username.getText().toString().trim());
        startActivity(intent);
    }
}

