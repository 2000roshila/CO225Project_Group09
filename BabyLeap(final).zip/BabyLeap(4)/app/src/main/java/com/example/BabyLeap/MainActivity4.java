package com.example.BabyLeap;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.example.BabyLeap.ui.Users;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.DateFormat;
import java.util.Calendar;

public class MainActivity4 extends AppCompatActivity {



    EditText babyname,nickname,birthday,weight,height;
    RadioButton radioButton;
    RadioGroup radioGroup;
    DatabaseReference reff;
    String username;
    Button back4,next4,upload;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        Calendar calendar=Calendar.getInstance();
        String currentDate= DateFormat.getDateInstance(DateFormat.SHORT).format(calendar.getTime());

        back4 =(Button)findViewById(R.id.back4);
        next4=(Button)findViewById(R.id.next4);
        radioGroup=findViewById(R.id.radio4);
        babyname=(EditText)findViewById(R.id.babyname);
        nickname=(EditText)findViewById(R.id.nickname);
        birthday=(EditText)findViewById(R.id.bithdate);
        weight=(EditText)findViewById(R.id.weight);
        height=(EditText)findViewById(R.id.height);
        int radioId=radioGroup.getCheckedRadioButtonId();
        radioButton=findViewById(radioId);
        Users user=getIntent().getParcelableExtra("DB_INSTANCE");
        username=getIntent().getStringExtra("USERNAME");
        reff= FirebaseDatabase.getInstance().getReference("Users");

        next4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                user.setBabyname(babyname.getText().toString().trim());
                user.setNickname(nickname.getText().toString().trim());
                user.setBirthday(birthday.getText().toString().trim());
                user.setWeight(weight.getText().toString().trim());
                user.setHeight(height.getText().toString().trim());
                user.setBabyGender(radioButton.getText().toString().trim());
                user.setWeightMod(currentDate);
                user.setHeightMod(currentDate);
                reff.child(username).setValue(user);
                openActivity10();

            }
        });


    }

    private void openActivity10() {

        Intent intent =new Intent(this,MainActivity10.class);
        intent.putExtra("USERNAME",username);
        startActivity(intent);
    }

    public void checkButton(View v) {

        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioId);

    }



}