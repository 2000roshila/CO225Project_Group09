package com.example.BabyLeap;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity6a extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity6a);
    }
}