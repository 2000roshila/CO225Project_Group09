package com.example.BabyLeap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.util.Calendar;

public class MainActivity9 extends AppCompatActivity {

    int today,birth,month;
    String username;
    Button save,goBack;
    CheckBox checkStatus;
    DatabaseReference reff,reff2;
    EditText vaccineDue,vaccineDueDate,administeredDate;
    int number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main9);

        username=getIntent().getStringExtra("USERNAME");
        Calendar calendar=Calendar.getInstance();

        vaccineDue=(EditText)findViewById(R.id.vaccineDue);
        vaccineDueDate=(EditText)findViewById(R.id.vaccineDueDate);
        administeredDate=(EditText)findViewById(R.id.AdministeredDate);
        save=(Button)findViewById(R.id.save);
        goBack=(Button)findViewById(R.id.goback);
        checkStatus=(CheckBox)findViewById(R.id.checkStatus);



        reff= FirebaseDatabase.getInstance().getReference().child("Vaccines").child(username);
        reff.addValueEventListener(new ValueEventListener() {



            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {



                if(snapshot.child("stateVaccine9").getValue().equals(true)){
                    vaccineDue.setText("All Vaccines Administered");
                    vaccineDueDate.setText("1All Vaccines Administered");


                }

                else if(snapshot.child("stateVaccine8").getValue().equals(true)){
                    vaccineDue.setText("DPT ,b Oral Polio Vaccine(bOPV)");
                    vaccineDueDate.setText("At 60 Months Old");
                    number=9;


                }
                else if(snapshot.child("stateVaccine7").getValue().equals(true)){
                    vaccineDue.setText("Measles, Mumps and Rubella");
                    vaccineDueDate.setText("At 36 Months Old");
                    number=8;


                }
                else if(snapshot.child("stateVaccine6").getValue().equals(true)){
                    vaccineDue.setText("Diptheria, Pertussis and Tetanus(DPT) Booster ,b Oral Polio Vaccine(bOPV) Booster");
                    vaccineDueDate.setText("At 18 Months Old");
                    number=7;


                }
                else if(snapshot.child("stateVaccine5").getValue().equals(true)){
                    vaccineDue.setText("Japanese Encephalitis");
                    vaccineDueDate.setText("At 18 Months Old");
                    number=6;

                }
                else if(snapshot.child("stateVaccine4").getValue().equals(true)){
                    vaccineDue.setText("Measles, mumps and Rubella");
                    vaccineDueDate.setText("At 9 Months Old");
                    number=5;

                }

                else if(snapshot.child("stateVaccine3").getValue().equals(true)){
                    vaccineDue.setText("Hepatitis B Vaccine 3 ,DPT - 3 ,Haemophilus Influenza type b Vaccine - 3 ,b Oral Polio Vaccine (boPV - 3)");
                    vaccineDueDate.setText("At 6 Months Old");
                    number=4;

                }

                else if(snapshot.child("stateVaccine2").getValue().equals(true)){
                    vaccineDue.setText("Hepatitis B Vaccine 2  ,DPT - 2  ,Haemophilus Influenza type b Vaccine - 2 ,b Oral Polio Vaccine (boPV - 2) ,Inactivated Poliovirus Vaccine(IPV-2)");
                    vaccineDueDate.setText("At 4 Months Old");
                    number=3;

                }

                else if(snapshot.child("stateVaccine1").getValue().equals(true)){
                    vaccineDue.setText("Hepatitis B Vaccine 1 ,DPT - 1 ,Haemophilus Influenza type b Vaccine - 1 ,b Oral Polio Vaccine (boPV - 1) ,Inactivated Poliovirus Vaccine(IPV-1)");
                    vaccineDueDate.setText("At 2 Months Old");
                    number=2;

                }



             else{
                    vaccineDue.setText("BCG");
                    vaccineDueDate.setText("At 0 Months Old");
                    number=1;

                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        reff2= FirebaseDatabase.getInstance().getReference().child("Vaccines").child(username);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkStatus.isChecked()){
                    reff2.child("administeredDate"+number).setValue(administeredDate.getText().toString().trim());
                    reff2.child("stateVaccine"+number).setValue(true);
                    openActivity9();
                }


            }
        });
        goBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity5();
            }
        });



    }

    private void openActivity5() {
        Intent intent =new Intent(this,MainActivity5.class);
        intent.putExtra("USERNAME",username);
        startActivity(intent);
    }

    private void openActivity9() {
        Intent intent =new Intent(this,MainActivity9.class);
        intent.putExtra("USERNAME",username);
        startActivity(intent);

    }
}