package com.example.BabyLeap;

public class Vaccines {

    private String vaccine1;
    private String vaccine2;
    private String vaccine3;
    private String vaccine4;
    private String vaccine5;
    private String vaccine6;
    private String vaccine7;
    private String vaccine8;
    private String vaccine9;

    private String username;



    private String administeredDate1;
    private String administeredDate2;
    private String administeredDate3;
    private String administeredDate4;
    private String administeredDate5;
    private String administeredDate6;
    private String administeredDate7;
    private String administeredDate8;
    private String administeredDate9;

    boolean stateVaccine1;
    boolean stateVaccine2;
    boolean stateVaccine3;
    boolean stateVaccine4;
    boolean stateVaccine5;
    boolean stateVaccine6;
    boolean stateVaccine7;
    boolean stateVaccine8;
    boolean stateVaccine9;

    public Vaccines(){

        administeredDate1="0";
        administeredDate2="0";
        administeredDate3="0";
        administeredDate4="0";
        administeredDate5="0";
        administeredDate6="0";
        administeredDate7="0";
        administeredDate8="0";
        administeredDate9="0";

        vaccine1="BCG";
        vaccine2="Hepatitis B Vaccine 1 ,DPT - 1 ,Haemophilus Influenza type b Vaccine - 1 ,b Oral Polio Vaccine (boPV - 1) ,Inactivated Poliovirus Vaccine(IPV-1)";
        vaccine3="Hepatitis B Vaccine 2  ,DPT - 2  ,Haemophilus Influenza type b Vaccine - 2 ,b Oral Polio Vaccine (boPV - 2) ,Inactivated Poliovirus Vaccine(IPV-2)";
        vaccine4="Hepatitis B Vaccine 3 ,DPT - 3 ,Haemophilus Influenza type b Vaccine - 3 ,b Oral Polio Vaccine (boPV - 3)";
        vaccine5="Measles, mumps and Rubella";
        vaccine6="Japanese Encephalitis";
        vaccine7="Diptheria, Pertussis and Tetanus(DPT) Booster ,b Oral Polio Vaccine(bOPV) Booster";
        vaccine8="Measles, Mumps and Rubella";
        vaccine9="DPT ,b Oral Polio Vaccine(bOPV)";




    }

    public boolean isStateVaccine1() {
        return stateVaccine1;
    }

    public void setStateVaccine1(boolean stateVaccine1) {
        this.stateVaccine1 = stateVaccine1;
    }

    public boolean isStateVaccine2() {
        return stateVaccine2;
    }

    public void setStateVaccine2(boolean stateVaccine2) {
        this.stateVaccine2 = stateVaccine2;
    }

    public boolean isStateVaccine3() {
        return stateVaccine3;
    }

    public void setStateVaccine3(boolean stateVaccine3) {
        this.stateVaccine3 = stateVaccine3;
    }

    public boolean isStateVaccine4() {
        return stateVaccine4;
    }

    public void setStateVaccine4(boolean stateVaccine4) {
        this.stateVaccine4 = stateVaccine4;
    }

    public boolean isStateVaccine5() {
        return stateVaccine5;
    }

    public void setStateVaccine5(boolean stateVaccine5) {
        this.stateVaccine5 = stateVaccine5;
    }

    public boolean isStateVaccine6() {
        return stateVaccine6;
    }

    public void setStateVaccine6(boolean stateVaccine6) {
        this.stateVaccine6 = stateVaccine6;
    }

    public boolean isStateVaccine7() {
        return stateVaccine7;
    }

    public void setStateVaccine7(boolean stateVaccine7) {
        this.stateVaccine7 = stateVaccine7;
    }

    public boolean isStateVaccine8() {
        return stateVaccine8;
    }

    public void setStateVaccine8(boolean stateVaccine8) {
        this.stateVaccine8 = stateVaccine8;
    }

    public boolean isStateVaccine9() {
        return stateVaccine9;
    }

    public void setStateVaccine9(boolean stateVaccine9) {
        this.stateVaccine9 = stateVaccine9;
    }




    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getVaccine1() {
        return vaccine1;
    }

    public void setVaccine1(String vaccine1) {
        this.vaccine1 = vaccine1;
    }

    public String getVaccine2() {
        return vaccine2;
    }

    public void setVaccine2(String vaccine2) {
        this.vaccine2 = vaccine2;
    }

    public String getVaccine3() {
        return vaccine3;
    }

    public void setVaccine3(String vaccine3) {
        this.vaccine3 = vaccine3;
    }

    public String getVaccine4() {
        return vaccine4;
    }

    public void setVaccine4(String vaccine4) {
        this.vaccine4 = vaccine4;
    }

    public String getVaccine5() {
        return vaccine5;
    }

    public void setVaccine5(String vaccine5) {
        this.vaccine5 = vaccine5;
    }

    public String getVaccine6() {
        return vaccine6;
    }

    public void setVaccine6(String vaccine6) {
        this.vaccine6 = vaccine6;
    }

    public String getVaccine7() {
        return vaccine7;
    }

    public void setVaccine7(String vaccine7) {
        this.vaccine7 = vaccine7;
    }

    public String getVaccine8() {
        return vaccine8;
    }

    public void setVaccine8(String vaccine8) {
        this.vaccine8 = vaccine8;
    }

    public String getVaccine9() {
        return vaccine9;
    }

    public void setVaccine9(String vaccine9) {
        this.vaccine9 = vaccine9;
    }

    public String getAdministeredDate1() {
        return administeredDate1;
    }

    public void setAdministeredDate1(String administeredDate1) {
        this.administeredDate1 = administeredDate1;
    }

    public String getAdministeredDate2() {
        return administeredDate2;
    }

    public void setAdministeredDate2(String administeredDate2) {
        this.administeredDate2 = administeredDate2;
    }

    public String getAdministeredDate3() {
        return administeredDate3;
    }

    public void setAdministeredDate3(String administeredDate3) {
        this.administeredDate3 = administeredDate3;
    }

    public String getAdministeredDate4() {
        return administeredDate4;
    }

    public void setAdministeredDate4(String administeredDate4) {
        this.administeredDate4 = administeredDate4;
    }

    public String getAdministeredDate5() {
        return administeredDate5;
    }

    public void setAdministeredDate5(String administeredDate5) {
        this.administeredDate5 = administeredDate5;
    }

    public String getAdministeredDate6() {
        return administeredDate6;
    }

    public void setAdministeredDate6(String administeredDate6) {
        this.administeredDate6 = administeredDate6;
    }

    public String getAdministeredDate7() {
        return administeredDate7;
    }

    public void setAdministeredDate7(String administeredDate7) {
        this.administeredDate7 = administeredDate7;
    }

    public String getAdministeredDate8() {
        return administeredDate8;
    }

    public void setAdministeredDate8(String administeredDate8) {
        this.administeredDate8 = administeredDate8;
    }

    public String getAdministeredDate9() {
        return administeredDate9;
    }

    public void setAdministeredDate9(String administeredDate9) {
        this.administeredDate9 = administeredDate9;
    }
}
