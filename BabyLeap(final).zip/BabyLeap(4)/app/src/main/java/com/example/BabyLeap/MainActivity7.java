package com.example.BabyLeap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.util.Calendar;

public class MainActivity7 extends AppCompatActivity {

    String username, nickname,birthday,HeightMod,Height,NewDate;
    int averageHeight, heightDiff;
    DatabaseReference reference,reff2;
    EditText heightLastMod,heightNewMod,heightval,description;
    int age ;
    int months_since_birth,month_new;
    Button save,goback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);

        Calendar calendar= Calendar.getInstance();
        String currentDate= DateFormat.getDateInstance(DateFormat.SHORT).format(calendar.getTime());

        heightLastMod=(EditText)findViewById(R.id.heightLastMod);
        heightNewMod=(EditText)findViewById(R.id.heightNewMod);
        heightval=(EditText)findViewById(R.id.heightval);
        description=(EditText)findViewById(R.id.description);
        save=(Button)findViewById(R.id.save);
        goback=(Button)findViewById(R.id.goback);

        username=getIntent().getStringExtra("USERNAME");
        reference= FirebaseDatabase.getInstance().getReference().child("Users").child(username);


        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                heightLastMod.setText(snapshot.child("heightMod").getValue().toString().trim());
                heightval.setText(Height);
                HeightMod = snapshot.child("heightMod").getValue().toString().trim();
                Height = snapshot.child("height").getValue().toString().trim();
                birthday = snapshot.child("birthday").getValue().toString();
                heightNewMod.setText((Integer.parseInt(HeightMod.substring(0, 1)) + 1) + HeightMod.substring(1));
                heightval.setText(Height);
                months_since_birth=Integer.parseInt(birthday.substring(0,1))+(Integer.parseInt(birthday.substring(5,7))+2000)*12;

                NewDate=heightNewMod.getText().toString().trim();
                month_new=Integer.parseInt(NewDate.substring(0,1))+(Integer.parseInt(NewDate.substring(5,7))+2000)*12;
                age=month_new-months_since_birth;

                if(age<=6){
                    averageHeight = 66;
                    heightDiff = Integer.parseInt(Height) - averageHeight;
                }
                else if(age<=12){
                    averageHeight = 75;
                    heightDiff = Integer.parseInt(Height) - averageHeight;
                }
                else if(age<=18){
                    averageHeight = 81;
                    heightDiff = Integer.parseInt(Height) - averageHeight;
                }
                else if(age<=24){
                    averageHeight = 86;
                    heightDiff = Integer.parseInt(Height) - averageHeight;
                }


                else if(age<=36){
                    averageHeight = 95;
                    heightDiff = Integer.parseInt(Height) - averageHeight;
                }
                else if(age<=48){
                    averageHeight = 101;
                    heightDiff = Integer.parseInt(Height) - averageHeight;
                }
                else {
                    averageHeight = 109;
                    heightDiff = Integer.parseInt(Height) - averageHeight;
                }

                description.setText(" Babies height "+Height+"kg at "+age+" months old. "+"The typical height for a child at this age is "+averageHeight+"kg. ");

            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });











        reff2= FirebaseDatabase.getInstance().getReference().child("Users").child(username);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reff2.child("height").setValue(heightval.getText().toString().trim());
                reff2.child("heightMod").setValue(currentDate);
                openActivity7();
            }
        });
        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity5();
            }
        });




    }

    private void openActivity5() {
        Intent intent =new Intent(this,MainActivity5.class);
        intent.putExtra("USERNAME",username);
        startActivity(intent);
    }

    private void openActivity7() {
        Intent intent =new Intent(this,MainActivity7.class);
        intent.putExtra("USERNAME",username);
        startActivity(intent);

    }


}