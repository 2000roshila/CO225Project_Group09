package com.example.BabyLeap.ui;

import android.os.Parcel;
import android.os.Parcelable;

public class Users implements Parcelable {
    private String parentname,nic,username,password,email,gender,babyname,nickname,birthday,weight,height,babyGender,weightMod,heightMod;



    public Users() {
    }

    protected Users(Parcel in) {
        parentname = in.readString();
        nic = in.readString();
        username = in.readString();
        password = in.readString();
        email = in.readString();
        gender = in.readString();
        babyname = in.readString();
        nickname = in.readString();
        birthday = in.readString();
        weight = in.readString();
        height = in.readString();
        babyGender = in.readString();
        weightMod=in.readString();
        heightMod=in.readString();

    }



    public String getBabyname() {
        return babyname;
    }

    public void setBabyname(String babyname) {
        this.babyname = babyname;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getBabyGender() {
        return babyGender;
    }

    public void setBabyGender(String babyGender) {
        this.babyGender = babyGender;
    }

    public String getWeightMod() {
        return weightMod;
    }

    public void setWeightMod(String weightMod) {
        this.weightMod = weightMod;
    }

    public String getHeightMod() {
        return heightMod;
    }

    public void setHeightMod(String heightMod) {
        this.heightMod = heightMod;
    }


    public static final Creator<Users> CREATOR = new Creator<Users>() {
        @Override
        public Users createFromParcel(Parcel in) {
            return new Users(in);
        }

        @Override
        public Users[] newArray(int size) {
            return new Users[size];
        }
    };

    public String getParentname() {
        return parentname;
    }

    public void setParentname(String parentname) {
        this.parentname = parentname;
    }

    public String getNic() {
        return nic;
    }

    public void setNic(String nic) {
        this.nic = nic;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(parentname);
        dest.writeString(nic);
        dest.writeString(username);
        dest.writeString(password);
        dest.writeString(email);
        dest.writeString(gender);
        dest.writeString(babyname);
        dest.writeString(nickname);
        dest.writeString(birthday);
        dest.writeString(weight);
        dest.writeString(height);
        dest.writeString(babyGender);
        dest.writeString(weightMod);
        dest.writeString(heightMod);
    }
}
