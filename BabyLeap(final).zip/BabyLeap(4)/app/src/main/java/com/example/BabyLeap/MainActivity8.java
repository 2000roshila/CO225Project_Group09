package com.example.BabyLeap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.util.Calendar;

public class MainActivity8 extends AppCompatActivity {

    String username, nickname, birthday, WeightMod, Weight, NewDate;
    int averageWeight, weightDiff;
    DatabaseReference reference, reff2;
    EditText weightLastMod, weightNewMod, weightval, description;
    int age;
    int months_since_birth, month_new;
    Button save, goback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main8);

        Calendar calendar = Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance(DateFormat.SHORT).format(calendar.getTime());

        weightLastMod = (EditText) findViewById(R.id.weightLastMod);
        weightNewMod = (EditText) findViewById(R.id.weightNewMod);
        weightval = (EditText) findViewById(R.id.weightval);
        description = (EditText) findViewById(R.id.description);
        save = (Button) findViewById(R.id.save);
        goback = (Button) findViewById(R.id.goback);

        username = getIntent().getStringExtra("USERNAME");
        reference = FirebaseDatabase.getInstance().getReference().child("Users").child(username);


        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                weightLastMod.setText(snapshot.child("weightMod").getValue().toString().trim());
                weightval.setText(Weight);
                WeightMod = snapshot.child("weightMod").getValue().toString().trim();
                Weight = snapshot.child("weight").getValue().toString().trim();
                birthday = snapshot.child("birthday").getValue().toString();
                weightNewMod.setText((Integer.parseInt(WeightMod.substring(0, 1)) + 1) + WeightMod.substring(1));
                weightval.setText(Weight);
                months_since_birth = Integer.parseInt(birthday.substring(0, 1)) + (Integer.parseInt(birthday.substring(5, 7)) + 2000) * 12;

                NewDate = weightNewMod.getText().toString().trim();
                month_new = Integer.parseInt(NewDate.substring(0, 1)) + (Integer.parseInt(NewDate.substring(5, 7)) + 2000) * 12;
                age = month_new - months_since_birth;

                if (age <= 6) {
                    averageWeight = 66;
                    weightDiff = Integer.parseInt(Weight) - averageWeight;
                } else if (age <= 12) {
                    averageWeight = 75;
                    weightDiff = Integer.parseInt(Weight) - averageWeight;
                } else if (age <= 18) {
                    averageWeight = 81;
                    weightDiff = Integer.parseInt(Weight) - averageWeight;
                } else if (age <= 24) {
                    averageWeight = 86;
                    weightDiff = Integer.parseInt(Weight) - averageWeight;
                } else if (age <= 36) {
                    averageWeight = 95;
                    weightDiff = Integer.parseInt(Weight) - averageWeight;
                } else if (age <= 48) {
                    averageWeight = 101;
                    weightDiff = Integer.parseInt(Weight) - averageWeight;
                } else {
                    averageWeight = 109;
                    weightDiff = Integer.parseInt(Weight) - averageWeight;
                }

                description.setText(" Babies weight " + Weight + "kg at " + age + " months old. " + "The typical weight for a child at this age is " + averageWeight + "kg. ");

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        reff2 = FirebaseDatabase.getInstance().getReference().child("Users").child(username);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reff2.child("weight").setValue(weightval.getText().toString().trim());
                reff2.child("weightMod").setValue(currentDate);
                openActivity8();
            }
        });
        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity5();
            }
        });


    }

    private void openActivity5() {
        Intent intent = new Intent(this, MainActivity5.class);
        intent.putExtra("USERNAME", username);
        startActivity(intent);
    }

    private void openActivity8() {
        Intent intent = new Intent(this, MainActivity8.class);
        intent.putExtra("USERNAME", username);
        startActivity(intent);

    }
}


