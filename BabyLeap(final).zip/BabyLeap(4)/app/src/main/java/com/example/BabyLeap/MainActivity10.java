package com.example.BabyLeap;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity10 extends AppCompatActivity {

    EditText administeredDate1, administeredDate2,administeredDate3,administeredDate4,administeredDate5,administeredDate6,administeredDate7,administeredDate8,administeredDate9;
    CheckBox vaccine1, vaccine2,vaccine3,vaccine4,vaccine5,vaccine6,vaccine7,vaccine8,vaccine9 ;
    Button save;
    DatabaseReference reference;
    Vaccines vaccine;
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main10);

        username=getIntent().getStringExtra("USERNAME");

        vaccine = new Vaccines();

        vaccine1 = findViewById(R.id.vaccine1);
        vaccine2 = findViewById(R.id.vaccine2);
        vaccine3 = findViewById(R.id.vaccine3);
        vaccine4 = findViewById(R.id.vaccine4);
        vaccine5 = findViewById(R.id.vaccine5);
        vaccine6 = findViewById(R.id.vaccine6);
        vaccine7 = findViewById(R.id.vaccine7);
        vaccine8 = findViewById(R.id.vaccine8);
        vaccine9 = findViewById(R.id.vaccine9);

        administeredDate1 = (EditText)findViewById(R.id.administeredDate1);
        administeredDate2 = (EditText)findViewById(R.id.administeredDate2);
        administeredDate3 = (EditText)findViewById(R.id.administeredDate3);
        administeredDate4 = (EditText)findViewById(R.id.administeredDate4);
        administeredDate5 = (EditText)findViewById(R.id.administeredDate5);
        administeredDate6 = (EditText)findViewById(R.id.administeredDate6);
        administeredDate7 = (EditText)findViewById(R.id.administeredDate7);
        administeredDate8 = (EditText)findViewById(R.id.administeredDate8);
        administeredDate9 = (EditText)findViewById(R.id.administeredDate9);
        save =(Button)findViewById(R.id.save);

        reference= FirebaseDatabase.getInstance().getReference("Vaccines").child(username);


        String v1 = "BCG";
        String v2 = "Hepatitis B Vaccine 1 \\nDPT - 1 \\nHaemophilus Influenza type b Vaccine - 1 \\nb Oral Polio Vaccine (boPV - 1) \\nInactivated Poliovirus Vaccine(IPV-1)";
        String v3 = "Hepatitis B Vaccine 2 \\nDPT - 2 \\nHaemophilus Influenza type b Vaccine - 2 \\nb Oral Polio Vaccine (boPV - 2) \\nInactivated Poliovirus Vaccine(IPV-2)";
        String v4 = "Hepatitis B Vaccine 3 \\nDPT - 3 \\nHaemophilus Influenza type b Vaccine - 3 \\nb Oral Polio Vaccine (boPV - 3) ";
        String v5 = "Measles, mumps and Rubella";
        String v6 = "Japanese Encephalitis";
        String v7 = "Diptheria, Pertussis and Tetanus(DPT) Booster \\nb Oral Polio Vaccine(bOPV) Booster";
        String v8 = "Measles, Mumps and Rubella";
        String v9 = "DPT \\nb Oral Polio Vaccine(bOPV)";

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(vaccine1.isChecked()){
                    vaccine.setVaccine1(v1);
                    vaccine.setStateVaccine1(true);
                    vaccine.setAdministeredDate1(administeredDate1.getText().toString().trim());
                }
                else{

                }
                if(vaccine2.isChecked()){
                    vaccine.setVaccine2(v2);
                    vaccine.setStateVaccine2(true);
                    vaccine.setAdministeredDate2(administeredDate2.getText().toString().trim());
                }
                else{

                }
                if(vaccine3.isChecked()){
                    vaccine.setVaccine3(v3);
                    vaccine.setStateVaccine3(true);
                    vaccine.setAdministeredDate3(administeredDate3.getText().toString().trim());
                }
                else{

                }
                if(vaccine4.isChecked()){
                    vaccine.setVaccine4(v4);
                    vaccine.setStateVaccine4(true);
                    vaccine.setAdministeredDate4(administeredDate4.getText().toString().trim());
                }
                else{

                }
                if(vaccine5.isChecked()){
                    vaccine.setVaccine5(v5);
                    vaccine.setStateVaccine5(true);
                    vaccine.setAdministeredDate5(administeredDate5.getText().toString().trim());
                }
                else{

                }
                if(vaccine6.isChecked()){
                    vaccine.setVaccine6(v6);
                    vaccine.setStateVaccine6(true);
                    vaccine.setAdministeredDate6(administeredDate6.getText().toString().trim());
                }
                else{

                }
                if(vaccine7.isChecked()){
                    vaccine.setVaccine7(v7);
                    vaccine.setStateVaccine7(true);
                    vaccine.setAdministeredDate7(administeredDate7.getText().toString().trim());
                }
                else{

                }
                if(vaccine8.isChecked()){
                    vaccine.setVaccine8(v8);
                    vaccine.setStateVaccine8(true);
                    vaccine.setAdministeredDate8(administeredDate8.getText().toString().trim());
                }
                else{

                }
                if(vaccine9.isChecked()){
                    vaccine.setVaccine9(v9);
                    vaccine.setStateVaccine9(true);
                    vaccine.setAdministeredDate9(administeredDate9.getText().toString().trim());
                }
                else{

                }
                reference.setValue(vaccine);

                openActivity5();
            }
        });
    }

    private void openActivity5() {
        Intent intent =new Intent(this,MainActivity5.class);
        intent.putExtra("USERNAME",username);
        startActivity(intent);
    }
}